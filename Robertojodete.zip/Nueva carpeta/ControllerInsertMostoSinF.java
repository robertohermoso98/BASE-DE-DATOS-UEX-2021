package sample.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class ControllerInsertMostoSinF {

    @FXML
    private TextField msf_id_material3;

    @FXML
    private TextField msf_id_levadura;

    @FXML
    private TextField msf_id_material2;

    @FXML
    private TextField msf_id_agua;

    @FXML
    private TextField msf_id_material;

    @FXML
    private TextField msf_id_malta;

    @FXML
    private TextField msf_id_material1;

    @FXML
    private TextField msf_id_lupulo;

    @FXML
    private TextField msf_tiempo_oxidacion;

    @FXML
    private TextField msf_tiempo_fermentacion;

    @FXML
    private TextField msf_temperatura;

    @FXML
    void aceptar(ActionEvent event) {

    }

    @FXML
    void salir(ActionEvent event) {

    }

}