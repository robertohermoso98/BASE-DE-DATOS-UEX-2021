package sample.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class ControllerInserCerveza {

    @FXML
    private TextField cer_numero_sec;

    @FXML
    private TextField cer_id_material;

    @FXML
    private TextField cer_id_material3;

    @FXML
    private TextField cer_id_levadura;

    @FXML
    private TextField cer_id_material2;

    @FXML
    private TextField cer_id_agua;

    @FXML
    private TextField cer_id_material1;

    @FXML
    private TextField cer_id_lupulo;

    @FXML
    private TextField cer_id_malta;

    @FXML
    private TextField cer_año;

    @FXML
    private TextField cer_id_material4;

    @FXML
    private TextField cer_id_tiempo_trasvase;

    @FXML
    void aceptar(ActionEvent event) {

    }

    @FXML
    void salir(ActionEvent event) {

    }

}
