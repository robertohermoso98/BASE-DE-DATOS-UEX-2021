package sample.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
public class ControllerEliminarCerveza {

        @FXML
        private TextField cer_numero_sec;

        @FXML
        private TextField cer_año;

        @FXML
        void aceptar(ActionEvent event) {

        }

        @FXML
        void salir(ActionEvent event) {

        }

    }

