package sample.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class ControllerInsertLiquidoFrio {

    @FXML
    private TextField lif_id_material2;

    @FXML
    private TextField lif_id_agua;

    @FXML
    private TextField lif_id_material;

    @FXML
    private TextField lif_id_malta;

    @FXML
    private TextField lif_id_material1;

    @FXML
    private TextField lif_id_lupulo;

    @FXML
    private TextField lif_metodo;

    @FXML
    private TextField lif_temperatura;

    @FXML
    void aceptar(ActionEvent event) {

    }

    @FXML
    void salir(ActionEvent event) {

    }
}