package controller;
import conection.Conexion;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Menu;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.LinkedList;

public class Controller {

    private String tablaSelecionada;


    @FXML
    private TableView<LinkedList []> table;

    @FXML
    private Menu idTablas;

    @FXML
    private Menu idSsentencias;

    @FXML
    void MostrarCuadroConsultas(ActionEvent event)  {

    }

    @FXML
    void MostrarCuadroDeModificarTab(ActionEvent event) {

    }

    @FXML
    void MostrarCuadroDelete(ActionEvent event) {

    }

    @FXML
    void MostrarCuadroInsert(ActionEvent event) {

        // abrimos la ventana de isnercion de cervezas
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().
                getResource("../fxml/insert"+tablaSelecionada+".fxml"));

        Parent parent = null;
        try {
            parent = fxmlLoader.load();
            // Se recupera el objeto controlador asociado al diálogo
            if(tablaSelecionada.equals("cerveza")) {
                ControllerInserCerveza dialogController = fxmlLoader.getController();
            }else{
                if(tablaSelecionada.equals("mosto_sin_f")){
                    //ControllerInserCerveza dialogController = fxmlLoader.getController();
                }else{
                    if(tablaSelecionada.equals("liquido_frio")){
                        //ControllerInserCerveza dialogController = fxmlLoader.getController();
                    }
                    //ControllerInserCerveza dialogController = fxmlLoader.getController();
                }
            }
// Se establece la escena
            Scene scene = new Scene(parent, 600, 400);
// Se establece el stage
            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setScene(scene);
            stage.showAndWait();
//Una ve
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void MostrarSentencia1(ActionEvent event) {

    }

    @FXML
    void MostrarSentencia2(ActionEvent event) {

    }

    @FXML
    void MostrarSentencia3(ActionEvent event) {

    }

    public void laGranSolucion(String nombreDeLaCosaABuscar){
        LinkedList<String> listaNombresColumnas;
        LinkedList<String>[] datos;
        LinkedList<Objetos> dat = new LinkedList<Objetos>();
        // abro la conexion
        Conexion cn = new Conexion();
        try {
            cn.abrirConexion();
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            // cojo la lista de nombres y los datos de la tabla
            listaNombresColumnas= cn.obtenerNombreDeColumnas("agua");
            datos = cn.datosTabla("agua");
            // creo la lista con los objetos

            for(int i=0; i<3;i++){
                dat.add(new Objetos());

            }

            for(int e =0; e<datos.length;e++){
                int contador=0;
                Iterator it = datos[e].iterator();
                while(it.hasNext()){
                    String nombre =(String) it.next();
                    dat.get(contador).datos.add(nombre);
                    contador++;

                }
            }
            ObservableList data = FXCollections.observableList(dat);
            table.setItems(data);
            //la tableview es table
            for (int i=0; i< listaNombresColumnas.size();i++) {
                final int cont=i;
                TableColumn veces = new TableColumn();
                veces.setText(listaNombresColumnas.get(i));
                veces.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Objetos, String>, ObservableValue<String>>() {
                    @Override
                    public ObservableValue<String> call(TableColumn.CellDataFeatures<Objetos, String> p) {
                        return new SimpleStringProperty(String.valueOf(p.getValue().datos.get(cont)));
                    }
                });
                table.getColumns().add(veces);
            }
            //table.getColumns().setAll(veces);
            table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }

    @FXML
    void mostrarAgua(ActionEvent event) {

        tablaSelecionada="agua";
        laGranSolucion(tablaSelecionada);
    }

    @FXML
    void mostrarAguaMin(ActionEvent event) {
        tablaSelecionada="agua_min";
        laGranSolucion(tablaSelecionada);
    }

    @FXML
    void mostrarCerveza(ActionEvent event) {
        tablaSelecionada="cerveza";
        laGranSolucion(tablaSelecionada);
    }

    @FXML
    void mostrarCervezaEnCab(ActionEvent event) {
        tablaSelecionada="cerveza_en_cab";
        laGranSolucion(tablaSelecionada);

    }

    @FXML
    void mostrarCervezaEnLin(ActionEvent event) {
        tablaSelecionada="cerveza_en_lib";
        laGranSolucion(tablaSelecionada);

    }

    @FXML
    void mostrarLevadura(ActionEvent event) {
        tablaSelecionada="levadura";
        laGranSolucion(tablaSelecionada);
    }

    @FXML
    void mostrarLiquidoDulce(ActionEvent event) {
        tablaSelecionada="liquido_dulce";
        laGranSolucion(tablaSelecionada);
    }

    @FXML
    void mostrarLiquidoFrio(ActionEvent event) {
        tablaSelecionada="liquido_frio";
        laGranSolucion(tablaSelecionada);
    }

    @FXML
    void mostrarLupulo(ActionEvent event) {
        tablaSelecionada="lupulo";
        laGranSolucion(tablaSelecionada);
    }

    @FXML
    void mostrarMalta(ActionEvent event) {
        tablaSelecionada="malta";
        laGranSolucion(tablaSelecionada);
    }

    @FXML
    void mostrarMaltaMolida(ActionEvent event) {
        tablaSelecionada="malta_molida";
        laGranSolucion(tablaSelecionada);
    }

    @FXML
    void mostrarMateriales(ActionEvent event) {
        tablaSelecionada="materiales";
        laGranSolucion(tablaSelecionada);
    }

    @FXML
    void mostrarMosto(ActionEvent event) {
        tablaSelecionada="mosto";
        laGranSolucion(tablaSelecionada);
    }

    @FXML
    void mostrarMostoSinF(ActionEvent event) {
        tablaSelecionada="mosto_sin_f";
        laGranSolucion(tablaSelecionada);
    }

    @FXML
    void mostrarPaises(ActionEvent event) {
        tablaSelecionada="paises";
        laGranSolucion(tablaSelecionada);
    }

}
