package controller;

import java.util.LinkedList;

public class Objetos {
    public LinkedList<String> datos;

    public Objetos(){
        datos = new LinkedList<String>();
    }
}
